//
//  03_01_add.c
//
//
//  Created by k23060kk on 2023/04/27.
//

#include <stdio.h>

int main(int argc, const char* argv[]) {
  int a, b;  // aとbの宣言
  a = 2;     // aに2を代入
  b = 3;     // bに3を代入
  printf("%d + %d = %d\n", a, b, a + b);
  return 0;
}
