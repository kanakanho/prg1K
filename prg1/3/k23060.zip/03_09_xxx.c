//
//  03_09_xxx.c
//
//
//  Created by k23060kk on 2023/04/27.
//

#include <stdio.h>

int main(int argc, const char* argv[]) {
  int x;
  printf("x?");
  scanf("%d", &x);
  printf("x=%d, 2x=%d, 3x=9\n", x, x * 2, x * 3);
  return 0;
}
