//
//  02_01_helloWorld.c
//  
//
//  Created by k23060kk on 2023/04/20.
//

#include <stdio.h>

int main(int argc, const char * argv[]){
    
    int x = 5 , y = 3;
    printf("%d - %d = %d\n",x,y,x - y);
    return 0;
}
