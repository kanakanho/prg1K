//
//  02_01_helloWorld.c
//  
//
//  Created by k23060kk on 2023/04/20.
//

#include <stdio.h>

int main(int argc, const char * argv[]){
    printf("    # \n");
    printf("   # # \n");
    printf("  #   # \n");
    printf(" ####### \n");
    printf("#       # \n");
    return 0;
}
