#include <stdio.h>
#define HELLO "Hello, World!"

double deg2Rad(double);

int main(int argc, const char* argv[]) {
  printf("%s\n", HELLO);
  return 0;
}
