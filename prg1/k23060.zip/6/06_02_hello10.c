//
//  06_02_hello10.c
//
//
//  Created by k23060kk on 2023/05/25.
//

#include <stdio.h>

int main(int argc, const char* argv[]) {
  int i;                        // 変数iを宣言
  for (i = 0; i < 10; i++) {    // iが0から9まで繰り返す
    printf("Hello, World!\n");  // Hello, World!を表示
  }
  return 0;
}
