//
//  08_03_hello10.c
//
//
//  Created by k23060kk on 2023/06/8.
//

#include <stdio.h>

int main(int argc, const char* argv[]) {
  int count = 0;
  while (count < 10) {
    printf("Hello, World!\n");
    count += 1;
  }
  return 0;
}
