//
//  11_01_string1.c
//
//
//  Created by k23060kk on 2023/06/29.
//

#include <stdio.h>

int main(int argc, const char* argv[]) {
  char array[] = "abcde";
  printf("文字列: %s\n", array);
  return 0;
}
